#include "Pch.h"
#include "Logger/Logger.h"
#include <VulkanBase.h>
#include "Renderer/Renderer.h"

GLFWwindow* window;


int main()
{
	Log::init();

	Renderer a;


	return 0;
}